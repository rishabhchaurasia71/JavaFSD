package DS_SortAndSearch_PracticeProject1;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//Sorting a list of exam grades 

public class QuickSortEx_ExamScores {
    public static void main(String[] args) {
        List<Integer> grades = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        // Get grades from the user
        System.out.println("Enter exam grades (type 'done' when finished):");
        String input;
        while (!(input = scanner.next()).equals("done")) {
            int grade = Integer.parseInt(input);
            grades.add(grade);
        }

        System.out.println("Before sorting: " + grades);

        // Sort grades using QuickSort
        quickSort(grades);

        System.out.println("After sorting: " + grades);

        scanner.close();
    }

    public static void quickSort(List<Integer> grades) {
        if (grades == null || grades.size() <= 1) {
            return;
        }
        int n = grades.size();
        quickSortHelper(grades, 0, n - 1);
    }

    private static void quickSortHelper(List<Integer> grades, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(grades, low, high);
            quickSortHelper(grades, low, pivotIndex - 1);
            quickSortHelper(grades, pivotIndex + 1, high);
        }
    }

    private static int partition(List<Integer> grades, int low, int high) {
        int pivot = grades.get(high);
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (grades.get(j) < pivot) {
                i++;
                swap(grades, i, j);
            }
        }
        swap(grades, i + 1, high);
        return i + 1;
    }

    private static void swap(List<Integer> grades, int i, int j) {
        int temp = grades.get(i);
        grades.set(i, grades.get(j));
        grades.set(j, temp);
    }
}

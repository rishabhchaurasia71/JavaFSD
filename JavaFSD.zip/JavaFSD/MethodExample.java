package JavaFSD;

public class MethodExample {
    
    // Method with no parameters and no return value
    public static void sayHello() {
        System.out.println("Hello!");
    }
    
    // Method with parameters and return value
    public static int multiply(int a, int b) {
        return a * b;
    }
    
    // Method with variable number of parameters and return value
    public static int sum(int... numbers) {
        int sum = 0;
        for (int i : numbers) {
            sum += i;
        }
        return sum;
    }
    
    public static void main(String[] args) {
        
        // Calling a method with no parameters and no return value
        sayHello();
        
        // Calling a method with parameters and return value
        int result = multiply(2, 3);
        System.out.println("2 x 3 = " + result);
        
        // Calling a method with variable number of parameters and return value
        
        int sumResult = sum(1, 2, 3, 4, 5);
        System.out.println("1 + 2 + 3 + 4 + 5 = " + sumResult);
        
        // Defining and calling a method inside another method
        int x = 2;
        int y = 3;
        int product = multiply(x, y);
        System.out.println(x + " x " + y + " = " + product);
        
    }
}

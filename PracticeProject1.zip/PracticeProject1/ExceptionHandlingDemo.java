package PracticeProject1;


//import java.util.Random;
//
//public class UnResolvedExceptionHandlingDemo {
//    public static void main(String[] args) {
//        try {
//            performTransaction();
//            System.out.println("Transaction completed successfully.");
//        } catch (TransactionException e) {
//            handleTransactionException(e);
//        }
//    }
//
//    public static void performTransaction() throws TransactionException {
//        try {
//            // Step 1: Begin transaction
//            beginTransaction();
//
//            try {
//                // Step 2: Perform pre-transaction checks
//                performPreTransactionChecks();
//
//                try {
//                    // Step 3: Process payment
//                    processPayment();
//
//                    // Step 4: Perform post-payment operations
//                    performPostPaymentOperations();
//                } catch (PaymentProcessingException e) {
//                    // Step 3a: Handle payment processing exception
//                    logError("Payment processing failed: " + e.getMessage());
//                    throw new TransactionException("Transaction failed.", e);
//                }
//            } catch (PreTransactionChecksException e) {
//                // Step 2a: Handle pre-transaction checks exception
//                logError("Pre-transaction checks failed: " + e.getMessage());
//                throw new TransactionException("Transaction failed.", e);
//            } finally {
//                // Step 2b: Clean up resources from pre-transaction checks
//                cleanupPreTransactionChecks();
//            }
//        } catch (TransactionInitializationException e) {
//            // Step 1a: Handle transaction initialization exception
//            logError("Transaction initialization failed: " + e.getMessage());
//            throw new TransactionException("Transaction failed.", e);
//        } finally {
//            // Step 1b: Clean up resources from transaction initialization
//            cleanupTransaction();
//        }
//    }
//
//    public static void beginTransaction() throws TransactionInitializationException {
//        // Simulate transaction initialization failure
//        throw new TransactionInitializationException("Failed to initialize transaction.");
//    }
//
//    public static void performPreTransactionChecks() throws PreTransactionChecksException {
//        // Simulate pre-transaction checks failure
//        throw new PreTransactionChecksException("Pre-transaction checks failed.");
//    }
//
//    public static void processPayment() throws PaymentProcessingException {
//        // Simulate payment processing failure
//        Random random = new Random();
//        boolean success = random.nextBoolean();
//
//        if (!success) {
//            throw new PaymentProcessingException("Payment processing failed.");
//        }
//    }
//
//    public static void performPostPaymentOperations() {
//        // Perform post-payment operations
//        System.out.println("Performing post-payment operations.");
//    }
//
//    public static void cleanupPreTransactionChecks() {
//        // Clean up resources from pre-transaction checks
//        System.out.println("Cleaning up resources from pre-transaction checks.");
//    }
//
//    public static void cleanupTransaction() {
//        // Clean up resources from transaction initialization
//        System.out.println("Cleaning up resources from transaction initialization.");
//    }
//
//    public static void logError(String message) {
//        // Log the error
//        System.err.println("Error: " + message);
//    }
//
//    public static void handleTransactionException(TransactionException e) {
//        // Handle transaction exception
//        System.err.println("Transaction failed: " + e.getMessage());
//        System.err.println("Cause: " + e.getCause().getMessage());
//    }
//
//    static class TransactionException extends Exception {
//        public TransactionException(String message, Throwable cause) {
//            super(message, cause);
//        }
//    }
//
//    static class TransactionInitializationException extends Exception {
//        public TransactionInitializationException(String message) {
//            super(message);
//        }
//    }
//
//    static class PreTransactionChecksException extends Exception {
//        public PreTransactionChecksException(String message) {
//            super(message);
//        }
//    }
//
//    static class PaymentProcessingException extends Exception {
//        public PaymentProcessingException(String message) {
//            super(message);
//        }
//    }}
public class ExceptionHandlingDemo extends Thread {
    public static void main(String[] args) throws InterruptedException  {
    	String s = null;
    	try {
    	    System.out.println(s.toString());
    	} catch (NullPointerException e) {
    		
    	    System.out.println("Caught NullPointerException");
    	   
    	    Thread.sleep(2000);
    	    System.out.println( e.getMessage());
    	}
    	finally {
    		System.out.println("Finally Block Executed");
    	}
    }
}


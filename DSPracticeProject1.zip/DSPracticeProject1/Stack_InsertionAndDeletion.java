package DataStructPracticeProject;

import java.util.Scanner;

public class Stack_InsertionAndDeletion {
    private int[] stack;
    private int top;
    private int capacity;

    public Stack_InsertionAndDeletion(int capacity) {
        stack = new int[capacity];
        top = -1;
        this.capacity = capacity;
    }

    public void push(int element) {
        if (top == capacity - 1) {
            System.out.println("Stack is full. Cannot push element.");
        } else {
            top++;
            stack[top] = element;
            System.out.println("Element " + element + " pushed to the stack.");

            System.out.print("Current Stack: ");
            displayStack();
        }
    }

    public void pop() {
        if (top == -1) {
            System.out.println("Stack is empty. Cannot pop an element.");
        } else {
            int poppedElement = stack[top];
            top--;
            System.out.println("Element " + poppedElement + " popped from the stack.");

            System.out.print("Current Stack: ");
            displayStack();
        }
    }

    public void displayStack() {
        if (top == -1) {
            System.out.println("Stack is empty.");
        } else {
        	System.out.println("Complete  Updated Stack: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stack[i] + " ");
            }
            System.out.println();
        }
    }

   

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the capacity of the stack: ");
        int capacity = scanner.nextInt();
        Stack_InsertionAndDeletion stackExample = new Stack_InsertionAndDeletion(capacity);

        int choice;

        do {
            System.out.println("Stack Operations:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the element to push: ");
                    int element = scanner.nextInt();
                    stackExample.push(element);
                    break;
                case 2:
                    stackExample.pop();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }

        } while (choice != 3);

        stackExample.displayStack();

        scanner.close();
    }
}

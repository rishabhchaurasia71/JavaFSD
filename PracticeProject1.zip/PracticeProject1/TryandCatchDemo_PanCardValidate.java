package PracticeProject1;

import java.util.Scanner;

public class TryandCatchDemo_PanCardValidate {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter PAN Card number: ");
        String panCardNumber = scanner.nextLine();

        try {
            validatePANCard(panCardNumber);
            System.out.println("PAN Card number is valid!");
        } catch (InvalidPANCardException e) {
            System.out.println("Error: " + e.getMessage());
            // Handle the invalid PAN Card number
        }

        scanner.close();
    }

    public static void validatePANCard(String panCardNumber) throws InvalidPANCardException {
        if (panCardNumber == null || panCardNumber.trim().isEmpty()) {
            throw new InvalidPANCardException("PAN Card number is missing!");
        }

        if (!panCardNumber.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
            throw new InvalidPANCardException("Invalid PAN Card number format!");
        }
    }
}

class InvalidPANCardException extends Exception {
   
	private static final long serialVersionUID = 16548542765796999L;

	public InvalidPANCardException(String message) {
        super(message);
    }
}

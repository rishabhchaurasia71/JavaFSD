package DS_SortAndSearch_PracticeProject1;


// Example based  on Insertion Sort:
// Inserting clothes into a cupboard using a list:

import java.util.ArrayList;
import java.util.List;

class Clothing {
    private String type;
    private String color;

    public Clothing(String type, String color) {
        this.type = type;
        this.color = color;
    }

    public String getType() {
        return type;
    }

    public String getColor() {
        return color;
    }

    public String toString() {
        return color + " " + type;
    }
}

public class InsertionSort {
    public static void insertionSort(List<Clothing> clothes) {
        int n = clothes.size();

        for (int i = 1; i < n; i++) {
            Clothing key = clothes.get(i);
            int j = i - 1;

            while (j >= 0 && clothes.get(j).getColor().compareTo(key.getColor()) > 0) {
                clothes.set(j + 1, clothes.get(j));
                j--;
            }

            clothes.set(j + 1, key);
        }
    }

    public static void main(String[] args) {
        List<Clothing> clothes = new ArrayList<>();
        clothes.add(new Clothing("Shirt", "Blue"));
        clothes.add(new Clothing("Jeans", "Black"));
        clothes.add(new Clothing("T-Shirt", "White"));
        clothes.add(new Clothing("Sweater", "Red"));
        clothes.add(new Clothing("Dress", "Pink"));

        System.out.println("Before sorting:");
        System.out.println(clothes);

        insertionSort(clothes);

        System.out.println("After sorting (by color):");
        System.out.println(clothes);
    }
}

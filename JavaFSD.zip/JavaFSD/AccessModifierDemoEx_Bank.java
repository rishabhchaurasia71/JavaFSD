package JavaFSD;


 public class AccessModifierDemoEx_Bank {
    private String bankName;
    protected int totalCashInBank;
    int totalAccounts;
    public String managerName;

    public AccessModifierDemoEx_Bank(String bankName, int totalCashInBank, int totalAccounts, String managerName) {
        this.bankName = bankName;
        this.totalCashInBank = totalCashInBank;
        this.totalAccounts = totalAccounts;
        this.managerName = managerName;
    }

    public void displayBankDetails() {
        System.out.println("Bank Name: " + bankName);
        System.out.println("Total Cash in Bank: " + totalCashInBank);
        System.out.println("Total Accounts: " + totalAccounts);
        System.out.println("Manager Name: " + managerName);
    }
}

 

 
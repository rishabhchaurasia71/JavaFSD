package DS_SortAndSearch_PracticeProject1;

// The selection sort algorithm on a list of cars based on their prices.
import java.util.ArrayList;
import java.util.List;

class Car {
    private String make;
    private String model;
    private double price;

    public Car(String make, String model, double price) {
        this.make = make;
        this.model = model;
        this.price = price;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public String toString() {
        return make + " " + model + " ($" + price + ")";
    }
}

public class SelectionSort {
    public static void selectionSort(List<Car> cars) {
        int n = cars.size();

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;

            for (int j = i + 1; j < n; j++) {
                if (cars.get(j).getPrice() < cars.get(minIndex).getPrice()) {
                    minIndex = j;
                }
            }

            if (minIndex != i) {
                // Swap cars at positions i and minIndex
                Car temp = cars.get(i);
                cars.set(i, cars.get(minIndex));
                cars.set(minIndex, temp);
            }
        }
    }

    public static void main(String[] args) {
        // Create a list of cars
        List<Car> cars = new ArrayList<>();
        cars.add(new Car("Toyota", "Camry", 25000.0));
        cars.add(new Car("Honda", "Accord", 28000.0));
        cars.add(new Car("Ford", "Mustang", 40000.0));
        cars.add(new Car("Chevrolet", "Cruze", 22000.0));
        cars.add(new Car("BMW", "X5", 60000.0));

        System.out.println("Before sorting:");
        for (Car car : cars) {
            System.out.println(car);
        }

        selectionSort(cars);

        System.out.println("\nAfter sorting (by price):");
        for (Car car : cars) {
            System.out.println(car);
        }
    }
}

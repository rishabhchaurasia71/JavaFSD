package DSPracticeProject2;



import java.util.Scanner;

public class LongestIncreasingSub_Sequence {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();
        
        // Create the input list
        int[] list = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            list[i] = element;
        }
        
        // Find the longest increasing subsequence using linked list
        Node longestIncreasingSubsequence = findLongestIncreasingSubsequence(list);
        
        // Print the result
        System.out.print("Longest increasing subsequence: ");
        while (longestIncreasingSubsequence != null) {
            System.out.print(longestIncreasingSubsequence.value + " ");
            longestIncreasingSubsequence = longestIncreasingSubsequence.next;
        }
        System.out.println();
        
        scanner.close();
    }
    
    public static Node findLongestIncreasingSubsequence(int[] list) {
        // Create an array to store the length of the longest increasing subsequence ending at each position
        int[] dp = new int[list.length];
        
        // Create an array to store the previous index of the longest increasing subsequence ending at each position
        int[] prevIndices = new int[list.length];
        
        // Initialize dp and prevIndices for the first element
        dp[0] = 1;
        prevIndices[0] = -1;
        
        // Iterate over the input list from left to right
        for (int i = 1; i < list.length; i++) {
            dp[i] = 1;
            prevIndices[i] = -1;
            
            // Find the longest increasing subsequence ending at the current position
            for (int j = 0; j < i; j++) {
                if (list[i] > list[j] && dp[j] + 1 > dp[i]) {
                    dp[i] = dp[j] + 1;
                    prevIndices[i] = j;
                }
            }
        }
        
        // Find the index of the element with the maximum length of the longest increasing subsequence
        int maxLengthIndex = 0;
        for (int i = 1; i < list.length; i++) {
            if (dp[i] > dp[maxLengthIndex]) {
                maxLengthIndex = i;
            }
        }
        
        // Construct the longest increasing subsequence using the previous indices
        Node head = null;
        Node tail = null;
        int currentIndex = maxLengthIndex;
        while (currentIndex != -1) {
            Node newNode = new Node(list[currentIndex]);
            if (head == null) {
                head = newNode;
                tail = newNode;
            } else {
                newNode.next = head;
                head = newNode;
            }
            currentIndex = prevIndices[currentIndex];
        }
        
        return head;
    }
    
    static class Node {
        int value;
        Node next;
        
        Node(int value) {
            this.value = value;
            this.next = null;
        }
    }
}








//import java.util.*;
//
//public class LongestIncreasingSub_Sequence {
//
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Enter the elements separated by spaces: ");
//        String input = scanner.nextLine();
//
//        // Split the input string by spaces and convert it to a list of integers
//        List<Integer> list = new ArrayList<>();
//        String[] elements = input.split(" ");
//        for (String element : elements) {
//            list.add(Integer.parseInt(element));
//        }
//
//        // Find the longest increasing subsequence using Hashtable
//        List<Integer> longestIncreasingSubsequence = findLongestIncreasingSubsequence(list);
//
//        // Print the result
//        System.out.println("Longest increasing subsequence: " + longestIncreasingSubsequence);
//
//        scanner.close();
//    }
//
//    public static List<Integer> findLongestIncreasingSubsequence(List<Integer> list) {
//        // Create a Hashtable to store the longest increasing subsequence ending at each position
//        Map<Integer, List<Integer>> dp = new Hashtable<>();
//
//        // Initialize dp for the first element
//        List<Integer> initialList = new ArrayList<>();
//        initialList.add(list.get(0));
//        dp.put(0, initialList);
//
//        // Iterate over the input list from left to right
//        for (int i = 1; i < list.size(); i++) {
//            List<Integer> longestSubsequence = new ArrayList<>();
//            int maxLength = 0;
//
//            // Iterate over previous positions to find longest increasing subsequence ending at current position
//            for (int j = 0; j < i; j++) {
//                if (list.get(j) < list.get(i)) {
//                    List<Integer> previousSubsequence = dp.get(j);
//                    if (previousSubsequence.size() > maxLength) {
//                        longestSubsequence = new ArrayList<>(previousSubsequence);
//                        maxLength = previousSubsequence.size();
//                    }
//                }
//            }
//
//            // Add current element to longest increasing subsequence ending at current position
//            longestSubsequence.add(list.get(i));
//
//            // Add longest increasing subsequence ending at current position to dp
//            dp.put(i, longestSubsequence);
//        }
//
//        // Find the longest increasing subsequence
//        List<Integer> longestIncreasingSubsequence = new ArrayList<>();
//        for (List<Integer> subsequence : dp.values()) {
//            if (subsequence.size() > longestIncreasingSubsequence.size()) {
//                longestIncreasingSubsequence = new ArrayList<>(subsequence);
//            }
//        }
//
//        return longestIncreasingSubsequence;
//    }
//}

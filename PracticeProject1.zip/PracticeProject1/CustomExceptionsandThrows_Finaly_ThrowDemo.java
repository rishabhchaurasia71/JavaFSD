package PracticeProject1;

public class CustomExceptionsandThrows_Finaly_ThrowDemo {
    public static void main(String[] args) {
        try {
            divideNumbers(10, 0);
            System.out.println("Division result: " + divideNumbers(10, 2));
        } catch (DivideByZeroException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static int divideNumbers(int numerator, int denominator) throws DivideByZeroException {
        if (denominator == 0) {
            throw new DivideByZeroException("Cannot divide by zero.");
        }
        return numerator / denominator;
    }
}

class DivideByZeroException extends Exception {
    
	public  DivideByZeroException(String message) {
        super(message);
    }
}

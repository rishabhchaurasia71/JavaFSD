package DataStructPracticeProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FourthSmallestElement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the list elements (space-separated): ");
        String input = scanner.nextLine();

        List<Integer> numbers = extractNumbers(input);

        int fourthSmallest = findFourthSmallest(numbers);

        if (fourthSmallest != Integer.MAX_VALUE) {
            System.out.println("Fourth smallest element: " + fourthSmallest);
        } else {
            System.out.println("Insufficient number of elements.");
        }

        scanner.close();
    }

    private static List<Integer> extractNumbers(String input) {
        List<Integer> numbers = new ArrayList<>();
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(input);

        while (matcher.find()) {
            numbers.add(Integer.parseInt(matcher.group()));
        }

        return numbers;
    }

    private static int findFourthSmallest(List<Integer> numbers) {
        if (numbers.size() < 4) {
            return Integer.MAX_VALUE;
        }

        numbers.sort(null);

        return numbers.get(3);
    }
}

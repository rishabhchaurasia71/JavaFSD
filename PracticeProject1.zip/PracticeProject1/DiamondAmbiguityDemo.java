package PracticeProject1;

//Parent interface defining a common method
interface PaymentOption {
 void makePayment();
}

//First parent interface extending the PaymentOption interface
interface GooglePay extends PaymentOption {
 default void makePayment() {
     System.out.println("Payment made using Google Pay.");
 }
}

//Second parent interface extending the PaymentOption interface
interface PhonePe extends PaymentOption {
 default void makePayment() {
     System.out.println("Payment made using PhonePe.");
 }
}

//Child class implementing the PaymentOption interface and resolving conflicts
class Payment implements GooglePay, PhonePe {
 public void makePayment() {
     GooglePay.super.makePayment(); // Resolving conflict by explicitly invoking method from GooglePay
 }
}

//Main class to run the program
public class DiamondAmbiguityDemo {
 public static void main(String[] args) {
     Payment payment = new Payment();
     payment.makePayment();
 }
}

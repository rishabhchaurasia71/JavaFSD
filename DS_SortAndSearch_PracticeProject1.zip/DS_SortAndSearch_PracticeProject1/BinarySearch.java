package DS_SortAndSearch_PracticeProject1;

import java.util.List;


public class BinarySearch {
    public static int binarySearch(List<Book> books, String key) {
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = key.compareTo(books.get(mid).getTitle());

            if (comparison == 0) {
                return mid; // Key found at index mid
            } else if (comparison < 0) {
                right = mid - 1; // Key is smaller, search in the left half
            } else {
                left = mid + 1; // Key is larger, search in the right half
            }
        }

        return -1; // Key not found
    }

    public static void main(String[] args) {
        // Create a sorted list of books
        List<Book> books = List.of(
            new Book("Java Fundamentals", "Joyce Farrel"),
            new Book("Core Java", "E.Balaguruswamy"),
            new Book("Advanced Java", "E.Balaguruswamy"),
            new Book("HQL", "Joyce Farrel"),
            new Book("JSP", "Joyce Farrel")
        );

        String key = "Advanced Java";
        int index = binarySearch(books, key);

        if (index != -1) {
            System.out.println("Book found at index " + index);
        } else {
            System.out.println("Book not found");
        }
    }
}

class Book {
    private String title;
    private String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
}

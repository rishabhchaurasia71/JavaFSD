package JavaFSD;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

public class JavaCollectionsDemo {
    
    public static void main(String[] args) {
        
        // ArrayList example
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("apple");
        arrayList.add("banana");
        arrayList.add("cherry");
        System.out.println("ArrayList: " + arrayList);

        // LinkedList example
        LinkedList<String> linkedList = new LinkedList<String>();
        linkedList.add("dog");
        linkedList.add("cat");
        linkedList.add("mouse");
        System.out.println("LinkedList: " + linkedList);

        // Stack example
        Stack<String> stack = new Stack<String>();
        stack.push("red");
        stack.push("green");
        stack.push("blue");
        System.out.println("Stack: " + stack);

        // Queue example
        Queue<String> queue = new LinkedList<String>();
        queue.offer("one");
        queue.offer("two");
        queue.offer("three");
        System.out.println("Queue: " + queue);

        // HashSet example
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.add("apple");
        hashSet.add("banana");
        hashSet.add("cherry");
        System.out.println("HashSet: " + hashSet);

        // TreeSet example
        TreeSet<String> treeSet = new TreeSet<String>();
        treeSet.add("dog");
        treeSet.add("cat");
        treeSet.add("mouse");
        System.out.println("TreeSet: " + treeSet);

        // HashMap example
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("USA", "Washington DC");
        hashMap.put("Canada", "Ottawa");
        hashMap.put("Mexico", "Mexico City");
        System.out.println("HashMap: " + hashMap);

        // TreeMap example
        TreeMap<String, String> treeMap = new TreeMap<String, String>();
        treeMap.put("dog", "mammal");
        treeMap.put("eagle", "bird");
        treeMap.put("snake", "reptile");
        System.out.println("TreeMap: " + treeMap);

        // Scanner example
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.println("Hello, " + name + "!");

    }
}

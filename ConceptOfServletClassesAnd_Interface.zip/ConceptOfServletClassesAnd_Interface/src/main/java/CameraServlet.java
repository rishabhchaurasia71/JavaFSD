import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CameraServlet extends HttpServlet implements Servlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cameraModel = request.getParameter("cameraModel");
        int rentalDuration = Integer.parseInt(request.getParameter("rentalDuration"));
        
        // Perform camera rental logic based on cameraModel and rentalDuration
        String rentalInfo = "You have rented a " + cameraModel + " for " + rentalDuration + " days.";
        
        response.setContentType("text/html");
        response.getWriter().println("<h1>Camera Rental Successful</h1>");
        response.getWriter().println("<p>" + rentalInfo + "</p>");
    }
}

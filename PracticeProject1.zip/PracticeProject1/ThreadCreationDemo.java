package PracticeProject1;

/*
 * interface runnable { public void run(); } public class ThreadDemoEx_ extends
 * Thread implements runnable {
 * 
 * public void run() { System.out.println("thread started"); } public static
 * void main(String[] args) throws InterruptedException { // TODO Auto-generated
 * method stub
 * 
 * ThreadDemoEx_ t = new ThreadDemoEx_(); Thread.sleep(1000); // thread is
 * started using start() method t.start();
 * 
 * }
 * 
 * 
 * }
 */
public class ThreadCreationDemo {
    public static void main(String[] args) {
        // Creating a thread by extending the 'Thread' class
        MyThread thread1 = new MyThread();
        thread1.start();

        // Creating a thread by implementing the 'Runnable' interface
        MyRunnable myRunnable = new MyRunnable();
        Thread thread2 = new Thread(myRunnable);
        thread2.start();
    }
}

// Thread class extending 'Thread'
class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("Thread created by extending 'Thread' class");
    }
}

// Runnable interface implementation
class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("Thread created by implementing 'Runnable' interface");
    }
}

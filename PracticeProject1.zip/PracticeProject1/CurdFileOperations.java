package PracticeProject1;

import java.io.File;
//import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;
import java.util.regex.Pattern;

public class CurdFileOperations {
    /**
     * @param args
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do
        {
        System.out.println("1. Create a file");
        System.out.println("2. Read a file");
        System.out.println("3. Update a file");
        System.out.println("4. Delete a file");
        //System.out.println("5. Write a file");
        System.out.println("Enter your choice (1-4): ");
        choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (choice) {
            case 1:
                System.out.print("Enter the file name to create: ");
                String createFileName = scanner.nextLine();
                createFile(createFileName);
                break;
            case 2:
                System.out.print("Enter the file name to read: ");
                String readFileName = scanner.nextLine();
                readFile(readFileName);
                break;
            case 3:
                System.out.print("Enter the file name to update: ");
                String updateFileName = scanner.nextLine();
                System.out.print("Enter the new file name: ");
                String newFileName = scanner.nextLine();
                updateFile(updateFileName, newFileName);
                break;
            case 4:
                System.out.print("Enter the file name to delete: ");
                String deleteFileName = scanner.nextLine();
                deleteFile(deleteFileName);
                break;
//            case 5:
//            	System.out.print("Enter the file name to write: ");
//            	String writeFileName = scanner.nextLine();
//            	System.out.print("Enter the data to write: ");
//                String data = scanner.nextLine();
//                writeFile(writeFileName,data);
//                break;
            default:
                System.out.println("Invalid choice!");
        }
        System.out.print("Do you want to continue? (Y/N): ");
        String continueChoice = scanner.nextLine();
        if ((!continueChoice.equalsIgnoreCase("Y") ) &&(!Pattern.matches("(?i)^(yes|y|yess*)$", continueChoice))) {
            break;
        }
    } while (true);
        scanner.close();
    }

    public static void createFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getAbsolutePath());
            } else {
                System.out.println("File already exists!");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }

//    public static void writeFile(String filename, String data) {
//        try (FileWriter writer = new FileWriter(filename)) {
//            writer.write(data);
//            System.out.println("Data written to file successfully");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
    public static void readFile(String fileName) {
        try {
            String content = new String(Files.readAllBytes(new File(fileName).toPath()));
            System.out.println("File content:");
            System.out.println(content);
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    public static void updateFile(String fileName, String newFileName) {
        try {
            File file = new File(fileName);
            if (file.exists()) {
                File newFile = new File(newFileName);
                Files.copy(file.toPath(), newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                System.out.println("File updated. New file created: " + newFile.getAbsolutePath());
            } else {
                System.out.println("File does not exist!");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file: " + e.getMessage());
        }
    }

    public static void deleteFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.exists()) {
                if (file.delete()) {
                    System.out.println("File deleted: " + file.getAbsolutePath());
                } else {
                    System.out.println("Failed to delete the file!");
                }
            } else {
                System.out.println("File does not exist!");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while deleting the file: " + e.getMessage());
        }
    }
}

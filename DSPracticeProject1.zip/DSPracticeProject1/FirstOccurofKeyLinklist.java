package DataStructPracticeProject;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class FirstOccurofKeyLinklist {
    private static Node head;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a singly linked list
        createLinkedList(scanner);

        // Display the initial linked list
        System.out.print("Initial Linked List: ");
        displayLinkedList();

        // Take input of the key to be deleted
        System.out.print("\nEnter the key to be deleted: ");
        int key = scanner.nextInt();

        // Delete the first occurrence of the key in the linked list
        deleteFirstOccurrence(key);

        // Display the updated linked list
        System.out.print("Updated Linked List: ");
        displayLinkedList();

        scanner.close();
    }

    private static void createLinkedList(Scanner scanner) {
        System.out.print("Enter the number of elements in the linked list: ");
        int n = scanner.nextInt();

        if (n <= 0) {
            return;
        }

        System.out.println("Enter the elements of the linked list:");
        head = new Node(scanner.nextInt());
        Node currentNode = head;

        for (int i = 1; i < n; i++) {
            currentNode.next = new Node(scanner.nextInt());
            currentNode = currentNode.next;
        }
    }

    private static void displayLinkedList() {
        Node currentNode = head;
        while (currentNode != null) {
            System.out.print(currentNode.data + " ");
            currentNode = currentNode.next;
        }
        System.out.println();
    }

    private static void deleteFirstOccurrence(int key) {
        // Check if the linked list is empty
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        // Check if the key is present at the head of the linked list
        if (head.data == key) {
            head = head.next;
            System.out.println("Key " + key + " deleted from the linked list.");
            return;
        }

        // Traverse the linked list to find the key and its previous node
        Node currentNode = head;
        Node prevNode = null;

        while (currentNode != null && currentNode.data != key) {
            prevNode = currentNode;
            currentNode = currentNode.next;
        }

        // Check if the key is found in the linked list
        if (currentNode != null) {
            // Delete the node containing the key
            prevNode.next = currentNode.next;
            System.out.println("Key " + key + " deleted from the linked list.");
        } else {
            System.out.println("Key " + key + " not found in the linked list.");
        }
    }
}

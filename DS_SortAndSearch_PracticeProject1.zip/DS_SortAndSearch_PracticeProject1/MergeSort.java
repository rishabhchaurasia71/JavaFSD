package DS_SortAndSearch_PracticeProject1;

//Sorting a list of employee records based on their salaries
import java.util.ArrayList;
import java.util.List;

class Employee {
    private String name;
    private double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public String toString() {
        return "Employee [Name: " + name + ", Salary: " + salary + "]";
    }
}

public class MergeSort {
    public static void main(String[] args) {
        // Create employee records
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Pavan", 90000.0));
        employees.add(new Employee("Sunil", 40000.0));
        employees.add(new Employee("Michael", 150000.0));
        employees.add(new Employee("Nilesh", 60000.0));
        employees.add(new Employee("William Rose", 420000.0));

        System.out.println("Before sorting:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }

        // Sort employees using Merge Sort based on their salaries
        mergeSort(employees);

        System.out.println("\nAfter sorting (by salary):");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    public static synchronized void mergeSort(List<Employee> employees) {
        if (employees.size() <= 1) {
            return;
        }

        int mid = employees.size() / 2;
        List<Employee> left = new ArrayList<>(employees.subList(0, mid));
        List<Employee> right = new ArrayList<>(employees.subList(mid, employees.size()));

        mergeSort(left);
        mergeSort(right);

        merge(employees, left, right);
    }

    private static synchronized void merge(List<Employee> employees, List<Employee> left, List<Employee> right) {
        int i = 0, j = 0, k = 0;

        while (i < left.size() && j < right.size()) {
            if (left.get(i).getSalary() <= right.get(j).getSalary()) {
                employees.set(k++, left.get(i++));
            } else {
                employees.set(k++, right.get(j++));
            }
        }

        while (i < left.size()) {
            employees.set(k++, left.get(i++));
        }

        while (j < right.size()) {
            employees.set(k++, right.get(j++));
        }
    }
}

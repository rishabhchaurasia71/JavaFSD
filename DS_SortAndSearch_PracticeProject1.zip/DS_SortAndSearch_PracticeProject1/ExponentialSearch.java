package DS_SortAndSearch_PracticeProject1;

import java.util.List;

public class ExponentialSearch {
    public static <T extends Comparable<T>> int exponentialSearch(List<T> list, T key) {
        if (list.get(0).equals(key)) {
            return 0; // Key found at index 0
        }

        int size = list.size();
        int index = 1;

        while (index < size && list.get(index).compareTo(key) <= 0) {
            index *= 2; // Double the index for each iteration
        }

        return binarySearch(list, key, index / 2, Math.min(index, size - 1));
    }

    public static <T extends Comparable<T>> int binarySearch(List<T> list, T key, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = key.compareTo(list.get(mid));

            if (comparison == 0) {
                return mid; // Key found at index mid
            } else if (comparison < 0) {
                right = mid - 1; // Key is smaller, search in the left half
            } else {
                left = mid + 1; // Key is larger, search in the right half
            }
        }

        return -1; // Key not found
    }

    public static void main(String[] args) {
        // Create a sorted list of integers
        List<Integer> numbers = List.of(10, 20, 30, 40, 50, 60, 70, 80, 90, 100);

        int key = 50;
        int index = exponentialSearch(numbers, key);

        if (index != -1) {
            System.out.println("Key found at index " + index);
        } else {
            System.out.println("Key not found");
        }
    }
}

package DS_SortAndSearch_PracticeProject1;

import java.util.ArrayList;
import java.util.Scanner;

public class BubbleSort {
    public static void bubbleSort(ArrayList<Integer> numbers) {
        int n = numbers.size();

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (numbers.get(j) > numbers.get(j + 1)) {
                    // Swap numbers[j] and numbers[j + 1]
                    int temp = numbers.get(j);
                    numbers.set(j, numbers.get(j + 1));
                    numbers.set(j + 1, temp);
                }
            }
        }
    }

    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            numbers.add(element);
        }

        System.out.println("\nBefore sorting:");
        for (int number : numbers) {
            System.out.println(number);
        }

        bubbleSort(numbers);

        System.out.println("\nAfter sorting:");
        for (int number : numbers) {
            System.out.println(number);
        }

        scanner.close();
    }
}

package JavaFSD;

import java.util.HashMap;
import java.util.Map;

public class JavaMapsDemo {

    public static void main(String[] args) {
        
        // create a new HashMap instance
        Map<String, Integer> map = new HashMap<String, Integer>();
        
        // add some key-value pairs to the map
        map.put("apple", 1);
        map.put("banana", 2);
        map.put("cherry", 3);
        map.put("date", 4);
        map.put("elderberry", 5);
        
        // print the size of the map
        System.out.println("Map size: " + map.size());
        
        // print all the keys in the map
        System.out.println("Map keys: " + map.keySet());
        
        // print all the values in the map
        System.out.println("Map values: " + map.values());
        
        // print the value associated with a specific key
        System.out.println("Value for key 'banana': " + map.get("banana"));
        
        // remove a key-value pair from the map
        map.remove("date");
        
        // check if the map contains a specific key
        if(map.containsKey("date")) {
            System.out.println("Map contains key 'date'");
        } else {
            System.out.println("Map does not contain key 'date'");
        }
        
        // check if the map contains a specific value
        if(map.containsValue(5)) {
            System.out.println("Map contains value 5");
        } else {
            System.out.println("Map does not contain value 5");
        }
        
        // iterate over all the key-value pairs in the map
        System.out.println("Map entries:");
        for(Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }
}

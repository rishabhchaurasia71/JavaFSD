package DataStructPracticeProject;

import java.util.HashSet;
import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of rows for the first matrix: ");
        int rows1 = scanner.nextInt();

        System.out.print("Enter the number of columns for the first matrix: ");
        int cols1 = scanner.nextInt();

        HashSet<HashSet<Integer>> matrix1 = readMatrix(scanner, rows1, cols1);

        System.out.print("Enter the number of rows for the second matrix: ");
        int rows2 = scanner.nextInt();

        System.out.print("Enter the number of columns for the second matrix: ");
        int cols2 = scanner.nextInt();

        HashSet<HashSet<Integer>> matrix2 = readMatrix(scanner, rows2, cols2);

        if (cols1 != rows2) {
            System.out.println("Invalid matrix dimensions for multiplication.");
            scanner.close();
            return;
        }

        HashSet<HashSet<Integer>> result = multiplyMatrices(matrix1, matrix2);

        System.out.println("The resulting matrix after multiplication is:\n");
        printMatrix(result);

        scanner.close();
    }

    private static HashSet<HashSet<Integer>> readMatrix(Scanner scanner, int rows, int cols) {
        HashSet<HashSet<Integer>> matrix = new HashSet<>();

        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < rows; i++) {
            HashSet<Integer> row = new HashSet<>();
            for (int j = 0; j < cols; j++) {
                row.add(scanner.nextInt());
            }
            matrix.add(row);
        }

        return matrix;
    }

    private static HashSet<HashSet<Integer>> multiplyMatrices(HashSet<HashSet<Integer>> matrix1, HashSet<HashSet<Integer>> matrix2) {
        int rows1 = matrix1.size();
       
        int cols2 = matrix2.iterator().next().size();

        HashSet<HashSet<Integer>> result = new HashSet<>();
        for (int i = 0; i < rows1; i++) {
            HashSet<Integer> row = new HashSet<>();
            for (int j = 0; j < cols2; j++) {
                int sum = 0;
                for (HashSet<Integer> k : matrix2) {
                    sum += matrix1.iterator().next().toArray(new Integer[0])[j] * k.toArray(new Integer[0])[i];
                }
                row.add(sum);
            }
            result.add(row);
        }

        return result;
    }

    private static void printMatrix(HashSet<HashSet<Integer>> matrix) {
        for (HashSet<Integer> row : matrix) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}

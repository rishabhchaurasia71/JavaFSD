package filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class LoginFilter implements Filter {
    public void init(FilterConfig config) throws ServletException {
        // Initialization code
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String username = httpRequest.getParameter("username");
        String password = httpRequest.getParameter("password");

        // Perform authentication logic using username and password
        boolean isAuthenticated = authenticateUser(username, password); // Replace with your own authentication logic

        if (isAuthenticated) {
            // User is authenticated, allow the request to proceed to the servlet
            chain.doFilter(request, response);
        } else {
            // User is not authenticated, redirect to a login page or display an error
            response.setContentType("text/html");
            response.getWriter().println("<h1>Access Denied</h1>");
            response.getWriter().println("<p>Invalid username or password.</p>");
        }
    }

    private boolean authenticateUser(String username, String password) {
    	// Add your authentication logic here
        // This is just a simple example

        // Validate if the username and password match a predefined value
        if (username.equals("admin") && password.equals("password")) {
            return true; // Authentication successful
        } else {
            return false; // Authentication failed
        }
    }

	public void destroy() {
        // Cleanup code
    }
}

//import java.io.IOException;
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.FilterConfig;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//
//public class LoginFilter implements Filter {
//    public void init(FilterConfig filterConfig) throws ServletException {
//        // Initialization code
//    }
//    
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//        // Perform filtering logic before the servlet is executed
//        
//        // Example: Check if the user is logged in
//        boolean isLoggedIn = false; // Replace with your own logic
//        
//        if (isLoggedIn) {
//            // User is logged in, allow the request to proceed to the servlet
//            chain.doFilter(request, response);
//        } else {
//            // User is not logged in, redirect to a login page or display an error
//            response.setContentType("text/html");
//            response.getWriter().println("<h1>Access Denied</h1>");
//            response.getWriter().println("<p>Please login to access this page.</p>");
//        }
//        
//        // Perform filtering logic after the servlet is executed
//    }
//    
//    public void destroy() {
//        // Cleanup code
//    }
//}


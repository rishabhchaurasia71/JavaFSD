package DataStructPracticeProject;

import java.util.*;

public class DoublyLinklist_ForwardAndBackward {
    private static class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    private static Node head;

    public static void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }

        System.out.println("Element " + data + " inserted in the doubly linked list.");
    }

    public static void traverseForward() {
        System.out.println("Traversing the doubly linked list in forward direction:");

        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println();
    }

    public static void traverseBackward() {
        System.out.println("Traversing the doubly linked list in backward direction:");

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }

        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vector<Integer> vector = new Vector<>();

        System.out.print("Enter the number of elements: ");
        int count = scanner.nextInt();

        System.out.println("Enter the elements:");
        for (int i = 0; i < count; i++) {
            int element = scanner.nextInt();
            insert(element);
            vector.add(element);
        }

        traverseForward();
        traverseBackward();

        scanner.close();
    }
}

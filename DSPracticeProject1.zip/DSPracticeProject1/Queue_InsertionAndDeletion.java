package DataStructPracticeProject;

import java.util.Scanner;

public class Queue_InsertionAndDeletion {
    private int[] queue;
    private int front;
    private int rear;
    private int capacity;
    private int size;

    public Queue_InsertionAndDeletion(int capacity) {
        queue = new int[capacity];
        front = 0;
        rear = -1;
        this.capacity = capacity;
        size = 0;
    }

    public void enqueue(int element) {
        if (size == capacity) {
            System.out.println("Queue is full. Cannot enqueue element.");
        } else {
            rear = (rear + 1) % capacity;
            queue[rear] = element;
            size++;
            System.out.println("Element " + element + " enqueued to the queue.");

            System.out.print("Current Queue: ");
            displayQueue();
        }
    }

    public void dequeue() {
        if (size == 0) {
            System.out.println("Queue is empty. Cannot dequeue an element.");
        } else {
            int dequeuedElement = queue[front];
            front = (front + 1) % capacity;
            size--;
            System.out.println("Element " + dequeuedElement + " dequeued from the queue.");

            System.out.print("Current Queue: ");
            displayQueue();
        }
    }

    public void displayQueue() {
        if (size == 0) {
            System.out.println("Queue is empty.");
        } else {
            int count = 0;
            int i = front;
            while (count < size) {
                System.out.print(queue[i] + " ");
                i = (i + 1) % capacity;
                count++;
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the capacity of the queue: ");
        int capacity = scanner.nextInt();
        Queue_InsertionAndDeletion queueExample = new Queue_InsertionAndDeletion(capacity);

        int choice;

        do {
            System.out.println("Queue Operations:");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the element to enqueue: ");
                    int element = scanner.nextInt();
                    queueExample.enqueue(element);
                    break;
                case 2:
                    queueExample.dequeue();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }

        } while (choice != 3);
        queueExample.displayQueue();
        scanner.close();
    }
}

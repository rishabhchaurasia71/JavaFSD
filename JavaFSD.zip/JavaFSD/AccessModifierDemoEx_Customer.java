package JavaFSD;

public class AccessModifierDemoEx_Customer {
    private String name;
    private int age;
    private String address;
    private String accountType;
    private int accountNumber;
    private int balance;

    public AccessModifierDemoEx_Customer(String name, int age, String address, String accountType, int accountNumber, int balance) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.accountType = accountType;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void displayCustomerDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Address: " + address);
        System.out.println("Account Type: " + accountType);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }

    public int getBalance() {
        return balance;
    }

    public void deposit(int amount) {
        balance += amount;
    }

    public void withdraw(int amount) {
        balance -= amount;
    }

    protected void setAddress(String address) {
        this.address = address;
    }
}
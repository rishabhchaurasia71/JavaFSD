package DS_SortAndSearch_PracticeProject1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class LinearSearch {
	public static <T> List<Integer> linearSearch(List<T> list, T key) {
		List<Integer> indices = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equals(key)) {
				indices.add(i); // Add the index if key is found
			}
		}
		return indices; // Return the list of indices
	}

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		List<Integer> numbers = new ArrayList<>();

		System.out.println("Enter the elements (space-separated):");
		String[] input = reader.readLine().split(" ");
		for (String num : input) {
			int element = Integer.parseInt(num);
			numbers.add(element);
		}

		System.out.print("Enter the key to search: ");
		int key = Integer.parseInt(reader.readLine());

		List<Integer> indices = linearSearch(numbers, key);

		if (!indices.isEmpty()) {
			System.out.println("Key found at indices: " + indices);
		} else {
			System.out.println("Key not found");
		}
	}
}

//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.List;
//
//public class LinearSearch {
//    public static <T> int linearSearch(List<T> list, T key) {
//        for (int i = 0; i < list.size(); i++) {
//            if (list.get(i).equals(key)) {
//                return i; // Return the index if key is found
//            }
//        }
//        return -1; // Return -1 if key is not found
//    }
//
//    public static void main(String[] args) throws IOException {
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//
//        List<Integer> numbers = new ArrayList<>();
//
//        System.out.print("Enter the number of elements: ");
//        int n = Integer.parseInt(reader.readLine());
//
//        System.out.println("Enter the elements:");
//        for (int i = 0; i < n; i++) {
//            int element = Integer.parseInt(reader.readLine());
//            numbers.add(element);
//        }
//
//        System.out.print("Enter the key to search: ");
//        int key = Integer.parseInt(reader.readLine());
//
//        int index = linearSearch(numbers, key);
//
//        if (index != -1) {
//            System.out.println("Key found at index " + index);
//        } else {
//            System.out.println("Key not found");
//        }
//    }
//}

package PracticeProject1;

//Shape.java - Parent class
abstract class Shape {
 protected String color;

 public Shape(String color) {
     this.color = color;
 }

 public abstract double getArea();

 public abstract double getPerimeter();
}

//Circle.java - Subclass inheriting from Shape
class Circle extends Shape {
 private double radius;

 public Circle(String color, double radius) {
     super(color);
     this.radius = radius;
 }

 @Override
 public double getArea() {
     return Math.PI * radius * radius;
 }

 @Override
 public double getPerimeter() {
     return 2 * Math.PI * radius;
 }
}

//Rectangle.java - Subclass inheriting from Shape
class Rectangle extends Shape {
 private double length;
 private double width;

 public Rectangle(String color, double length, double width) {
     super(color);
     this.length = length;
     this.width = width;
 }

 @Override
 public double getArea() {
     return length * width;
 }

 @Override
 public double getPerimeter() {
     return 2 * (length + width);
 }
}

//Main.java - Main class to run the program
public class OopsConceptsDemo {
 public static void main(String[] args) {
     // Creating objects of Circle and Rectangle
     Circle circle = new Circle("Red", 10E1);
     Rectangle rectangle = new Rectangle("Blue", 1e1-3, 0.0E6+2);

     // Accessing properties and methods of objects
     System.out.println("Circle color: " + circle.color);
     System.out.println("Circle area: " + circle.getArea());
     System.out.println("Circle perimeter: " + circle.getPerimeter());

     System.out.println("Rectangle color: " + rectangle.color);
     System.out.println("Rectangle area: " + rectangle.getArea());
     System.out.println("Rectangle perimeter: " + rectangle.getPerimeter());
 }
}

package DataStructPracticeProject;

import java.util.*;
public class SumOfElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        int[] array = new int[n];

        System.out.print("Enter the elements (space-separated): ");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.print("Enter the range start index (L): ");
        int L = scanner.nextInt();

        System.out.print("Enter the range end index (R): ");
        int R = scanner.nextInt();

        int sum = findSumInRange(array, L, R);

        System.out.println("Sum of elements in the range of L and R: " + sum);

        scanner.close();
    }

    private static int findSumInRange(int[] array, int L, int R) {
        int sum = 0;

        // Validate the range
        if (L < 0 || R >= array.length || L > R) {
            throw new IllegalArgumentException("Invalid range.");
        }

        // Calculate the sum of elements in the given range
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }

        return sum;
    }
}
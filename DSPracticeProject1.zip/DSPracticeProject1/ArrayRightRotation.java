package DataStructPracticeProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArrayRightRotation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of steps to rotate: ");
        int rotateSteps = scanner.nextInt();

        // Consume the newline character
        scanner.nextLine();

        System.out.print("Enter the list elements (space-separated): ");
        String input = scanner.nextLine();

        List<Integer> array = parseList(input);

        System.out.println("Original List: " + array);

        // Right rotate the list by the specified number of steps
        rotateList(array, rotateSteps);

        System.out.println("Rotated List: " + array);

        scanner.close();
    }

    private static List<Integer> parseList(String input) {
        List<Integer> list = new ArrayList<>();
        String[] elements = input.split("\\s+");

        for (String element : elements) {
            list.add(Integer.parseInt(element));
        }

        return list;
    }

    private static void rotateList(List<Integer> list, int rotateSteps) {
        int size = list.size();

        // Adjust the number of steps if it exceeds the list size
        rotateSteps = rotateSteps % size;

        if (rotateSteps > 0) {
            // Remove the last element from the list
            Integer lastElement = list.remove(size - 1);
            // Add the last element to the beginning of the list
            list.add(0, lastElement);
            // Recursively rotate the remaining elements
            rotateList(list, rotateSteps - 1);
        }
    }
}






















//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//public class ArrayLeftRotation {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Enter the number of steps to rotate: ");
//        int rotateSteps = scanner.nextInt();
//
//        // Consume the newline character
//        scanner.nextLine();
//
//        System.out.print("Enter the list elements (space-separated): ");
//        String input = scanner.nextLine();
//
//        List<Integer> array = parseList(input);
//
//        System.out.println("Original List: " + array);
//
//        // Right rotate the list by the specified number of steps
//        rotateList(array, rotateSteps);
//
//        System.out.println("Rotated List: " + array);
//
//        scanner.close();
//    }
//
//    private static List<Integer> parseList(String input) {
//        List<Integer> list = new ArrayList<>();
//        String[] elements = input.split("\\s+");
//
//        for (String element : elements) {
//            list.add(Integer.parseInt(element));
//        }
//
//        return list;
//    }
//
//    private static void rotateList(List<Integer> list, int rotateSteps) {
//        int size = list.size();
//
//        // Adjust the number of steps if it exceeds the list size
//        rotateSteps = rotateSteps % size;
//
//        if (rotateSteps > 0) {
//            // Remove elements from the beginning and add them to the end
//            for (int i = 0; i < rotateSteps; i++) {
//                Integer element = list.remove(0);
//                list.add(element);
//            }
//        }
//    }
//}

package PracticeProject1;

class Parent {
    public synchronized void waitForKid() {
        try {
            System.out.println("Parent: Waiting for the kid to finish homework...");
            wait();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Parent: Kid finished homework! Time to go out.");
        
    }

    public synchronized void notifyParent() {
        System.out.println("Kid: Finished homework! Notifying parent...");
        notify();
    }
}

class Kid implements Runnable {
    private Parent parent;

    public Kid(Parent parent) {
        this.parent = parent;
    }

    @Override
    public void run() {
        try {
            System.out.println("Kid: Starting homework...");
            Thread.sleep(20000); // Simulating homework time
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        parent.notifyParent();
    }
}

public class SynchronizedDemo {
    public static void main(String[] args) {
        Parent parent = new Parent();
        Kid kid = new Kid(parent);

        Thread kidThread = new Thread(kid);

        kidThread.start();

        parent.waitForKid();
    }
}

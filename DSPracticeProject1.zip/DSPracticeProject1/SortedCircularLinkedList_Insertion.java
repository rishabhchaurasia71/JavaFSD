package DataStructPracticeProject;

import java.util.*;

public class SortedCircularLinkedList_Insertion {
    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    private static Node head;

    public static void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (data <= head.data) {
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = head;
        } else {
            Node current = head;
            while (current.next != head && data > current.next.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }

        System.out.println("Element " + data + " inserted in the sorted circular linked list.");
    }

    public static Node getLastNode() {
        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        return temp;
    }

    public static void displayList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of initial elements: ");
        int count = scanner.nextInt();

        System.out.println("Enter the initial elements for the sorted circular linked list: ");
        for (int i = 0; i < count; i++) {
            int element = scanner.nextInt();
            insert(element);
        }

        System.out.println("Enter the 'NEW' element to insert: ");
        int newElement = scanner.nextInt();
        insert(newElement);

        System.out.println("Updated Circular Linked List:");
        displayList();

        scanner.close();
    }
}
